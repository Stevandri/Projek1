<?php
    include("connection.php");
	include("header.php");
		
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Online Shopping cart</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<!--banner-->
<div class="banner-top">
	<div class="container">
		<h3 >About</h3>
		<h4><a href="index.php">Home</a><label>/</label>About</h4>
		<div class="clearfix"> </div>
	</div>
</div>

<!-- faqs -->
	<div class="about-w3 ">

			
			<!--about-->
			<div class="container">
		<div  class="about">
	<div class="spec ">
				<h3>About</h3>
					<div class="ser-t">
						<b></b>
						<span><i></i></span>
						<b class="line"></b>
					</div>
			</div>
			
			<div class="col-md-4 about-right">
			<img class="img-responsive" src="images/online_shopping3.jpg" alt="">
			</div>
			<div class="col-md-4 about-left">
				<p>Shopping Cart is the leading online marketplace in Pakistan,empowering tens of thousands of seller to connect with million of customers.Online Shopping Cart provides immediate and easy access to 10 million products in more than 100+ categories and delievers more than 2 million packages every month to all corners of its Country.
                Shopping Cart is a very popular online shopping platform from Karachi Pakistan.... Online Shopping was launched in 2021 as an online business-to-consumer platform.
                </p>
			</div>
			<div class="col-md-4 about-right">
			<img class="img-responsive" src="images/online_shopping2.jpg" alt="">
			</div>
			
			<div class="clearfix"> </div>
		</div>
	</div>
	<!--//about-->
	
	<!--work-experience-->
	<div  class="work">
		<div class="container">
			<div class="spec spec-w3ls">
				<h3>Our Journey</h3>
					<div class="ser-t">
						<b></b>
						<span><i></i></span>
						<b class="line"></b>
					</div>
			</div>
			<div class="work-info"> 
				<div class="col-md-6 work-left"> 
					<div class=" work-w3 "> 
						<h5>januray 2017</h5>
						<p>Why have we filed an article about corporate social responsibility- and Shopping Cart's undertakings therein- under Lifestyle?Our reasons are deliberate as they are specific: integrating social responsibility into the ebb & flow of on-the-go living, is what, we hope, will make it actionable.</p>
					</div>
					<label></label>
				</div>
				<div class="col-md-6 work-right"> 
					<div class=" work-w31"> 
						<h5> November 2012</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo </p>
					</div>
					<label></label>
				</div>
				<div class="clearfix"> </div>
				<span> 2017</span>
			</div>
			<div class="work-info"> 
				<div class="col-md-6 work-left"> 
					<div class=" work-w3 "> 
						<h5> June 2013</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo </p>
					</div>
					<label></label>
				</div>
				<div class="col-md-6 work-right"> 
					<div class=" work-w31"> 
						<h5>December 2013</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo </p>
					</div>
					<label></label>
				</div>
				<div class="clearfix"> </div>
				<span> 2013</span>
			</div>
			<div class="work-info"> 
				<div class="col-md-6 work-left"> 
					<div class=" work-w3 "> 
						<h5> April 2014</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo </p>
					</div>
					<label></label>
				</div>
				<div class="col-md-6 work-right"> 
					<div class=" work-w31"> 
						<h5> August 2014</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo </p>
					</div>
					<label></label>
				</div>
				<div class="clearfix"> </div>
				<span> 2014</span>
			</div>
			<div class="work-info"> 
				<div class="col-md-6 work-left"> 
					<div class=" work-w3 "> 
						<h5> February 2015</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo </p>
					</div>
					<label></label>
				</div>
				<div class="col-md-6 work-right"> 
					<div class=" work-w31"> 
						<h5> July 2015</h5>
						<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo </p>
					</div>
					<label></label>
				</div>
				<div class="clearfix"> </div>
				<span> 2015</span>
				<span class="last"> 2016</span>
			</div>
		</div>
	</div>
	<!--//work-experience-->
<!--advantages--> 
<div class="container">
	<div class="advantages">
			<div class="col-md-6 advantages-left ">
				<h3>Our Advantages</h3>
				<div class="advn-one">
						<div class="ad-mian">
							<div class="ad-left">
								<p>1</p>
							</div>
							<div class="ad-right">
								<h4><a href="single.html">24/7 Shopping:</a></h4>
								<p>The most important facility of online shopping is to shop anything at any time. For the availability of technology, anybody can shop now from Online Shopping cart at any time without any big effort definitely. </p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="ad-mian">
							<div class="ad-left">
								<p>2</p>
							</div>
							<div class="ad-right">
								<h4><a href="single.html">Time Saving:</a></h4>
								<p>If anybody want to save his or her most precious time, he or she should choose the online shopping without thinking any other option. In this regard, Online Shopping Cart can be the suitable choice obviously. </p>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="ad-mian">
							<div class="ad-left">
								<p>3</p>
							</div>
							<div class="ad-right">
								<h4><a href="single.html">Unbelievable Price:</a></h4>
								<p>As there are no middle businessmen in online market, the price of the products stay remained in customer’s comfort zone. So, the customers can pay only the legal price of any product in online shopping. On that note, Online Shopping Cart provides various facilities to their online customers like vast discount offers and delicious gift coupons unbelievably. </p>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
			</div>
			<div class="col-md-6 advantages-left about-agi">
				<h3>Our Skills</h3>
			<div class="advn-two">
						<h4><a href="single.html">Building an intuitive customer journey</a></h4>
						<p>With exposure to innovative technologies, Daraz has been able to establish an insightful consumer path. The company has built a deep awareness of consumer touchpoints not only to create a user interface that is personalized and easy to use but also to extend the physical presence and provide a comprehensive customer experience.</p>
						<ul>
							<li><a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i>Online Shopping is not just your virtual mall and online marketplace, but a community</a></li>
							<li><a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i>Paving the way towards financial inclusivity</a></li>
							<li><a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i>Customers easily Communicate with us</a></li>
							<li><a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i>CONDITIONS RELATED TO SALE OF THE PRODUCT OR SERVICE</a></li>
							<li><a href="#"> <i class="fa fa-angle-right" aria-hidden="true"></i>PLATFORM FOR COMMUNICATION</a></li>
						</ul>
			</div>
			</div>
			<div class="clearfix"></div>
		</div>
		</div>
	<!--advantages--> 

	</div>
	<!-- // Terms of use -->

     <!-- Include Footer -->
     <?php
	    include("footer.php");
	 ?>
	 <!-- Include Footer -->
       
</body>
</html>